/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000003039691025_1252848694_init();
    work_m_00000000003156877609_0438653480_init();
    work_m_00000000003917766764_0018197948_init();
    work_m_00000000003156877609_0054420329_init();
    work_m_00000000000378324711_4133793798_init();
    work_m_00000000002085143556_0553392083_init();
    work_m_00000000000407778786_1816195917_init();
    work_m_00000000001137142357_2254970523_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000001137142357_2254970523");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
