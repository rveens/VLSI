/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/BarrydeBruin/Documents/GitHub/VLSI/L3/project/lab3_part2/mainfilter.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static int ng3[] = {2, 0};



static void Cont_20_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 6432U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(20, ng0);
    t2 = (t0 + 5192);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 7624);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 1U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 0);
    t18 = (t0 + 7496);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_21_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 6680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(21, ng0);
    t2 = (t0 + 5352);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 7688);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 1U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 0);
    t18 = (t0 + 7512);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_36_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 6928U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 5512);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 7752);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t4, 8);
    xsi_driver_vfirst_trans(t5, 0, 31);
    t10 = (t0 + 7528);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Always_73_3(char *t0)
{
    char t13[8];
    char t18[8];
    char t25[8];
    char t54[8];
    char t61[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    int t44;
    int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    char *t52;
    char *t53;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    char *t65;
    char *t66;
    char *t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    char *t75;
    char *t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    int t85;
    int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    char *t93;

LAB0:    t1 = (t0 + 7176U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(73, ng0);
    t2 = (t0 + 7544);
    *((int *)t2) = 1;
    t3 = (t0 + 7208);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(73, ng0);

LAB5:    xsi_set_current_line(74, ng0);
    t4 = (t0 + 1752U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(79, ng0);

LAB10:    xsi_set_current_line(80, ng0);
    t2 = (t0 + 3032U);
    t3 = *((char **)t2);
    t2 = (t0 + 2992U);
    t4 = (t2 + 72U);
    t5 = *((char **)t4);
    t11 = (t0 + 2992U);
    t12 = (t11 + 48U);
    t14 = *((char **)t12);
    t15 = ((char*)((ng1)));
    xsi_vlog_generic_get_array_select_value(t13, 1, t3, t5, t14, 2, 1, t15, 32, 1);
    t16 = (t0 + 3032U);
    t17 = *((char **)t16);
    t16 = (t0 + 2992U);
    t19 = (t16 + 72U);
    t20 = *((char **)t19);
    t21 = (t0 + 2992U);
    t22 = (t21 + 48U);
    t23 = *((char **)t22);
    t24 = ((char*)((ng2)));
    xsi_vlog_generic_get_array_select_value(t18, 1, t17, t20, t23, 2, 1, t24, 32, 1);
    t6 = *((unsigned int *)t13);
    t7 = *((unsigned int *)t18);
    t8 = (t6 & t7);
    *((unsigned int *)t25) = t8;
    t26 = (t13 + 4);
    t27 = (t18 + 4);
    t28 = (t25 + 4);
    t9 = *((unsigned int *)t26);
    t10 = *((unsigned int *)t27);
    t29 = (t9 | t10);
    *((unsigned int *)t28) = t29;
    t30 = *((unsigned int *)t28);
    t31 = (t30 != 0);
    if (t31 == 1)
        goto LAB11;

LAB12:
LAB13:    t52 = (t0 + 3032U);
    t53 = *((char **)t52);
    t52 = (t0 + 2992U);
    t55 = (t52 + 72U);
    t56 = *((char **)t55);
    t57 = (t0 + 2992U);
    t58 = (t57 + 48U);
    t59 = *((char **)t58);
    t60 = ((char*)((ng3)));
    xsi_vlog_generic_get_array_select_value(t54, 1, t53, t56, t59, 2, 1, t60, 32, 1);
    t62 = *((unsigned int *)t25);
    t63 = *((unsigned int *)t54);
    t64 = (t62 & t63);
    *((unsigned int *)t61) = t64;
    t65 = (t25 + 4);
    t66 = (t54 + 4);
    t67 = (t61 + 4);
    t68 = *((unsigned int *)t65);
    t69 = *((unsigned int *)t66);
    t70 = (t68 | t69);
    *((unsigned int *)t67) = t70;
    t71 = *((unsigned int *)t67);
    t72 = (t71 != 0);
    if (t72 == 1)
        goto LAB14;

LAB15:
LAB16:    t93 = (t0 + 5192);
    xsi_vlogvar_wait_assign_value(t93, t61, 0, 0, 1, 0LL);
    xsi_set_current_line(81, ng0);
    t2 = (t0 + 3192U);
    t3 = *((char **)t2);
    t2 = (t0 + 3152U);
    t4 = (t2 + 72U);
    t5 = *((char **)t4);
    t11 = (t0 + 3152U);
    t12 = (t11 + 48U);
    t14 = *((char **)t12);
    t15 = ((char*)((ng1)));
    xsi_vlog_generic_get_array_select_value(t13, 1, t3, t5, t14, 2, 1, t15, 32, 1);
    t16 = (t0 + 3192U);
    t17 = *((char **)t16);
    t16 = (t0 + 3152U);
    t19 = (t16 + 72U);
    t20 = *((char **)t19);
    t21 = (t0 + 3152U);
    t22 = (t21 + 48U);
    t23 = *((char **)t22);
    t24 = ((char*)((ng2)));
    xsi_vlog_generic_get_array_select_value(t18, 1, t17, t20, t23, 2, 1, t24, 32, 1);
    t6 = *((unsigned int *)t13);
    t7 = *((unsigned int *)t18);
    t8 = (t6 & t7);
    *((unsigned int *)t25) = t8;
    t26 = (t13 + 4);
    t27 = (t18 + 4);
    t28 = (t25 + 4);
    t9 = *((unsigned int *)t26);
    t10 = *((unsigned int *)t27);
    t29 = (t9 | t10);
    *((unsigned int *)t28) = t29;
    t30 = *((unsigned int *)t28);
    t31 = (t30 != 0);
    if (t31 == 1)
        goto LAB17;

LAB18:
LAB19:    t52 = (t0 + 3192U);
    t53 = *((char **)t52);
    t52 = (t0 + 3152U);
    t55 = (t52 + 72U);
    t56 = *((char **)t55);
    t57 = (t0 + 3152U);
    t58 = (t57 + 48U);
    t59 = *((char **)t58);
    t60 = ((char*)((ng3)));
    xsi_vlog_generic_get_array_select_value(t54, 1, t53, t56, t59, 2, 1, t60, 32, 1);
    t62 = *((unsigned int *)t25);
    t63 = *((unsigned int *)t54);
    t64 = (t62 & t63);
    *((unsigned int *)t61) = t64;
    t65 = (t25 + 4);
    t66 = (t54 + 4);
    t67 = (t61 + 4);
    t68 = *((unsigned int *)t65);
    t69 = *((unsigned int *)t66);
    t70 = (t68 | t69);
    *((unsigned int *)t67) = t70;
    t71 = *((unsigned int *)t67);
    t72 = (t71 != 0);
    if (t72 == 1)
        goto LAB20;

LAB21:
LAB22:    t93 = (t0 + 5352);
    xsi_vlogvar_wait_assign_value(t93, t61, 0, 0, 1, 0LL);
    xsi_set_current_line(82, ng0);
    t2 = (t0 + 4632U);
    t3 = *((char **)t2);
    t2 = (t0 + 5512);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 32, 0LL);

LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(74, ng0);

LAB9:    xsi_set_current_line(75, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 5192);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 1, 0LL);
    xsi_set_current_line(76, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 5352);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(77, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 5512);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    goto LAB8;

LAB11:    t32 = *((unsigned int *)t25);
    t33 = *((unsigned int *)t28);
    *((unsigned int *)t25) = (t32 | t33);
    t34 = (t13 + 4);
    t35 = (t18 + 4);
    t36 = *((unsigned int *)t13);
    t37 = (~(t36));
    t38 = *((unsigned int *)t34);
    t39 = (~(t38));
    t40 = *((unsigned int *)t18);
    t41 = (~(t40));
    t42 = *((unsigned int *)t35);
    t43 = (~(t42));
    t44 = (t37 & t39);
    t45 = (t41 & t43);
    t46 = (~(t44));
    t47 = (~(t45));
    t48 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t48 & t46);
    t49 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t49 & t47);
    t50 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t50 & t46);
    t51 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t51 & t47);
    goto LAB13;

LAB14:    t73 = *((unsigned int *)t61);
    t74 = *((unsigned int *)t67);
    *((unsigned int *)t61) = (t73 | t74);
    t75 = (t25 + 4);
    t76 = (t54 + 4);
    t77 = *((unsigned int *)t25);
    t78 = (~(t77));
    t79 = *((unsigned int *)t75);
    t80 = (~(t79));
    t81 = *((unsigned int *)t54);
    t82 = (~(t81));
    t83 = *((unsigned int *)t76);
    t84 = (~(t83));
    t85 = (t78 & t80);
    t86 = (t82 & t84);
    t87 = (~(t85));
    t88 = (~(t86));
    t89 = *((unsigned int *)t67);
    *((unsigned int *)t67) = (t89 & t87);
    t90 = *((unsigned int *)t67);
    *((unsigned int *)t67) = (t90 & t88);
    t91 = *((unsigned int *)t61);
    *((unsigned int *)t61) = (t91 & t87);
    t92 = *((unsigned int *)t61);
    *((unsigned int *)t61) = (t92 & t88);
    goto LAB16;

LAB17:    t32 = *((unsigned int *)t25);
    t33 = *((unsigned int *)t28);
    *((unsigned int *)t25) = (t32 | t33);
    t34 = (t13 + 4);
    t35 = (t18 + 4);
    t36 = *((unsigned int *)t13);
    t37 = (~(t36));
    t38 = *((unsigned int *)t34);
    t39 = (~(t38));
    t40 = *((unsigned int *)t18);
    t41 = (~(t40));
    t42 = *((unsigned int *)t35);
    t43 = (~(t42));
    t44 = (t37 & t39);
    t45 = (t41 & t43);
    t46 = (~(t44));
    t47 = (~(t45));
    t48 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t48 & t46);
    t49 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t49 & t47);
    t50 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t50 & t46);
    t51 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t51 & t47);
    goto LAB19;

LAB20:    t73 = *((unsigned int *)t61);
    t74 = *((unsigned int *)t67);
    *((unsigned int *)t61) = (t73 | t74);
    t75 = (t25 + 4);
    t76 = (t54 + 4);
    t77 = *((unsigned int *)t25);
    t78 = (~(t77));
    t79 = *((unsigned int *)t75);
    t80 = (~(t79));
    t81 = *((unsigned int *)t54);
    t82 = (~(t81));
    t83 = *((unsigned int *)t76);
    t84 = (~(t83));
    t85 = (t78 & t80);
    t86 = (t82 & t84);
    t87 = (~(t85));
    t88 = (~(t86));
    t89 = *((unsigned int *)t67);
    *((unsigned int *)t67) = (t89 & t87);
    t90 = *((unsigned int *)t67);
    *((unsigned int *)t67) = (t90 & t88);
    t91 = *((unsigned int *)t61);
    *((unsigned int *)t61) = (t91 & t87);
    t92 = *((unsigned int *)t61);
    *((unsigned int *)t61) = (t92 & t88);
    goto LAB22;

}


extern void work_m_00000000002085143556_0553392083_init()
{
	static char *pe[] = {(void *)Cont_20_0,(void *)Cont_21_1,(void *)Cont_36_2,(void *)Always_73_3};
	xsi_register_didat("work_m_00000000002085143556_0553392083", "isim/filtertest_isim_beh.exe.sim/work/m_00000000002085143556_0553392083.didat");
	xsi_register_executes(pe);
}
